#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include "Pilha.h"
#include "Fila.h"
#include "Lista.h"

// Função para adicionar uma posição à fila
void adicionarFila(NoPilha *pilha, int posicao) {
    NoFila *novo = (NoFila *)malloc(sizeof(NoFila));

    novo->posicao = posicao;
    novo->proximo = pilha->fila;// Faz o novo nó apontar para o início
    pilha->fila = novo;//atualiza o topo da fila
}