#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include "Pilha.h"
#include "Fila.h"
#include "Lista.h"

// Função para percorrer a frase e encontrar termos
void Pilha(NoPilha *pilha) {
    int tam = strlen(pilha->frase);
    int i;
    for (i = 0; i < tam - 2; i++) {
        // Verificar se o termo "ATG" está presente
        if (pilha->frase[i] == 'A' && pilha->frase[i + 1] == 'T' && pilha->frase[i + 2] == 'G') {
            adicionarLista(pilha, "ATG");
            adicionarFila(pilha, i);
            i += 2;
        }
        // Verificar se o termo "TCC" está presente
        if (pilha->frase[i] == 'T' && pilha->frase[i + 1] == 'C' && pilha->frase[i + 2] == 'C') {
            adicionarLista(pilha, "TCC");
            adicionarFila(pilha, i);
            i += 2;
        }
        // Verificar se o termo "TTT" está presente
        if (pilha->frase[i] == 'T' && pilha->frase[i + 1] == 'T' && pilha->frase[i + 2] == 'T') {
            adicionarLista(pilha, "TTT");
            adicionarFila(pilha, i);
            i += 2;
        }
    }
}