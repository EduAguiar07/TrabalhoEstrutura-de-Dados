#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include "Pilha.h"
#include "Fila.h"
#include "Lista.h"

// Função para adicionar um termo à lista
void adicionarLista(NoPilha *pilha, const char *subfrase) {
    NoLista *novo = (NoLista *)malloc(sizeof(NoLista));

    strcpy(novo->subfrase, subfrase);
    novo->proximo = pilha->lista;// Faz o novo nó apontar para o início
    pilha->lista = novo;//Atualiza topo da lista para o novo nó, inserindo-o no início

  // Função para imprimir os valores armazenados na lista e nas posições correspondentes da fila
  
}