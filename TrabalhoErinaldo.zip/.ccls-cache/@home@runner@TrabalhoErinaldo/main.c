#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>
#include "Pilha.h"
#include "Fila.h"
#include "Lista.h"

void imprimirListaEPosicao(NoPilha *pilha) {
    NoLista *lista = pilha->lista;
    NoFila *fila = pilha->fila;

    // Verificar se a lista e a fila estão vazias
    if (lista == NULL && fila == NULL) {
        // Nenhum termo foi encontrado
        printf("Nenhum Termo encontrado\n");
        return;
    }

    // Percorre a lista e a fila juntas
    while (lista != NULL && fila != NULL) {
        // Imprime o termo encontrado e a posição correspondente
        printf("Termo encontrado: %s na posição %d\n", lista->subfrase, fila->posicao);

        // Avança para o próximo elemento da lista e da fila
        lista = lista->proximo;
        fila = fila->proximo;
    }
}



int main(void) {
  setlocale(LC_ALL, "Portuguese");
    NoPilha pilha;
    pilha.fila = NULL; // Inicializa a fila
    pilha.lista = NULL; // Inicializa a lista

  printf("Procurando Motivos genéticos “ATG”,“TCC” e “TTT”.\n");
    printf("Digite a Sequência (Maiúsculo): ");
    fgets(pilha.frase, sizeof(pilha.frase), stdin);
    for (int i = 0; pilha.frase[i] != '\0'; i++){
      pilha.frase[i] = toupper(pilha.frase[i]);
    }
    printf("\n");

    // Remove o '\n' do final da frase, se existir
    pilha.frase[strlen(pilha.frase) - 1] = '\0';

    // Chama a função Pilha para processar a frase
    Pilha(&pilha);

    // Imprime os resultados armazenados na lista e as posições correspondentes
    imprimirListaEPosicao(&pilha);

    // Libera a memória alocada para a fila e a lista
    NoFila *fila_atual = pilha.fila;
    while (fila_atual != NULL) {
        NoFila *temp = fila_atual;
        fila_atual = fila_atual->proximo;
        free(temp);
    }

    NoLista *lista_atual = pilha.lista;
    while (lista_atual != NULL) {
        NoLista *temp = lista_atual;
        lista_atual = lista_atual->proximo;
        free(temp);
    }
}