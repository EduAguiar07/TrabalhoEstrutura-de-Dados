#ifndef PILHA
#define PILHA

#include "Fila.h"
#include "Lista.h"

typedef struct {
    char frase[100]; // Frase do usuário
    NoFila *fila; // Fila para armazenar posições
    NoLista *lista; // Lista para armazenar termos encontrados
}NoPilha;

#endif