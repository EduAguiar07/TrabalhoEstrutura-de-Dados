#ifndef LISTA
#define LISTA

typedef struct NoLista {
    char subfrase[4]; // Armazena o termo encontrado ("ATG", "TCC", ou "TTT")
    struct NoLista *proximo;
}NoLista;

#endif