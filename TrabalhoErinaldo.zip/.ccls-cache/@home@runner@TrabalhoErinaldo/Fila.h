#ifndef FILA
#define FILA

typedef struct NoFila {
    int posicao; // Armazena a posição encontrada
    struct NoFila *proximo;
} NoFila;



#endif